/*
 * 一：装箱
 *  开辟一个新的内容空间 AAA333
 *  把属性名和属性值分别进行存储
 *    name : '珠峰'
 *    age : 9
 *    nick ： obj.name ... 此时开辟的空间和OBJ没有半毛钱关系，因为还没有给其赋值呢(OBJ此时的值是undefined) => undefined.name + 'is' + undefined.age => 只有对象才有键值对，所以会报错 => Cannot read property 'name' of undefined => JS中默认情况下上面代码报错，后续所有的操作都将不再执行
 */
var obj = {
    name: '珠峰',
    age: 9,
    nick: obj.name + ' is ' + obj.age //=>Uncaught TypeError: Cannot read property 'name' of undefined
};
console.log(obj.nick);