/*
 * 1、开辟一个空间(AAA111)，把NAME存储在空间中
 * 2、赋值
 *   var obj1 = `AAA111`;
 *   obj2 = `AAA111`;
 */
var obj1 = obj2 = {name: '珠峰'};
console.log(obj1 === obj2);//=>TRUE

/*
 * 1、开辟一个空间(AAA222)，存储NAME，把空间地址给OBJ1
 * 2、开辟一个空间(AAA333)，存储NAME，把空间地址给OBJ2
 */
var obj1 = {name: '珠峰'};
obj2 = {name: '珠峰'};
console.log(obj1 === obj2);//=>FALSE