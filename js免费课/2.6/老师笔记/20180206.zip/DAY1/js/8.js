// fn();//=>变量提升阶段完成了FN的创建,所以代码执行并不会报错 =>1
// function fn() {
//     console.log(1);
// }

/*
 * 变量提升：
 *   var fn;
 *   变量提升不会对等号右侧的进行操作（因为右侧是的值，值无法变量提升）
 */
// fn();//=>Uncaught TypeError: fn is not a function  //=>undefined()只有函数才可以执行
// var fn = function () {
//     console.log(1);
// };


//==============================================
/*
 * 变量提升：
 *   var fn; （在全局作用域中声明的变量是全局变量）
 * 代码执行：
 *   fn=创建函数,把函数的地址赋值给（创建SUM的时候并没有把SUM放在全局下，一般一个作用域中的变量都是在变量提升阶段声明的）
 *   =>fn=AAA000
 */
// var fn = function sum() {
//     console.log(sum, fn);
//     console.log(1);
// };
// fn();//=>1
// sum();//=>Uncaught ReferenceError: sum is not defined