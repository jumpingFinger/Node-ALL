//=>获取#BOX的UL
// var oBox = document.getElementById('box');
// console.dir(oBox);
/*
 * 获取的DOM元素是一个元素对象（对象）
 *   typeof oBox =>'object'
 *
 * childElementCount：存储的是当前容器元素子节点的个数
 * childNodes：所有的子节点(包含：文本、注释、元素)
 * children：所有的元素子节点
 * className：元素样式类名 'box clearfix'
 * classList：元素样式集合 [0:'box',1:'clearfix',length:2,value:'box clearfix']
 * firstChild：第一个子节点
 * firstElementChild：第一个元素子节点
 * id：元素的ID
 * innerHTML：元素中的内容 （识别HTML标签）
 * innerText：元素中的内容 （只认文本）
 * lastChild/lastElementChild：最后一个（元素）子节点
 * nextSibling/nextElementSibling：下一个弟弟（元素）节点
 * nodeName：节点名称
 * nodeType：节点类型
 * nodeValue：节点值
 * outerHTML/outerText：相对于innerXxx的区别是包含了当前元素本身
 * parentElement/parentNode：父亲节点
 * previousSibling/previousElementSibling：上一个哥哥（元素）节点
 * style：存储的是当前元素所有的“行内样式”（只有把样式写在行内上才可以获取到）
 * tagName：元素标签名（一般都是大写）
 *
 * onxxx：当前元素的相关事件属性
 *   onclick
 *   onmouse(over/out)
 *   ...
 */


// var oBox = document.getElementsByTagName('ul');
// console.dir(oBox[0]);
/*
 * getElementsByTagName/getElementsByName/getElementsByClassName/querySelectorAll 获取到的都是元素或者节点集合（类数组：类似数组但是不是数组，但是属于对象类型的）
 *
 * =>oBox
 *   0:UL元素对象
 *   length:1
 *
 * =>oBox=oBox[0];
 *   UL元素对象
 */

// var oBox = document.querySelector('#box');
// console.dir(oBox);

//=>直接通过ID当做元素对象使用也可以（我们一般会在前面加一个WINDOW）
// console.dir(box);
// console.dir(window.box);

//...

var oList = window.box.getElementsByTagName('li');
for (var i = 0; i < oList.length; i++) {
    /*
     * 第一轮循环：i=0  oList[0]第一个LI
     * 第二轮循环：i=1  oList[1]第二个LI
     * ...
     * oList[i] 当前本轮循环对应的LI
     */
    var item = oList[i],
        bg = item.style.backgroundColor;
    if (i % 2 === 0) {
        bg = 'red';
    } else {
        bg = 'green';
    }
}








