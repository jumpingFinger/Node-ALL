/*
 * var a=0,b=0;  VS  var a=b=0;
 *   [第一种]
 *     var a=0;
 *     var b=0;
 *
 *   [第二种]
 *     var a=0;
 *     b=0; 除了A以外其余的都没有VAR过
 */

var num1 = 12,
    num2 = num1;
num2 = 13;
console.log(num1);//=>12

var obj1 = {name: '珠峰', age: 9},
    obj2 = obj1;
obj2['name'] = '培训';
console.log(obj1.name);//=>'培训'



