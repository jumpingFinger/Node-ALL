// var fn = function sum() {
//     console.log(sum, fn);//=>SUM在函数里面是可以使用的
//     console.log(1);
// };
// fn();//=>1
// sum();//=>Uncaught ReferenceError: sum is not defined

/*
 * 函数对应的空间如果是AAA000的话:
 * 1、fn=AAA000
 * 2、sum=AAA000
 *
 * 问题：sum只能在函数内部被调用，fn在函数里面或者外面都可以调用
 */


/*
 * JS中变量提升的机制
 *   在当前作用域中，JS代码自上而下执行之前，浏览器会默认做一些事情：把所有带VAR/FUNCTION关键词的进行提前声明或者定义  =>JS的变量提升机制
 *
 * [声明 Declare]
 *   var a;
 *   告诉浏览器有这样的一个东西
 *
 * [定义 Defined]
 *   a=12;
 *   给这个东西赋值
 *
 * 带VAR的只是提前声明，带FUNCTION提前声明加定义
 */

/*
 * 加载页面[全局作用域window]
 *  变量提升:
 *    var a;  （变量在变量提升阶段：只声明，默认值undefined未定义）
 *    fn=AAA000 （函数在变量提升阶段：声明+定义）
 *
 *  代码执行：
 */
console.log(a, fn);//=>undefined  函数本身
var a = 12; //=>由于VAR A已经在变量提升阶段完成了（浏览器比较懒，做过一遍的绝对不会重新做第二遍），本次执行只需要完成 a=12 的赋值操作即可

function fn() {
    console.log(1);
}//=>由于变量提升阶段已经创建了函数，此处直接的跳过即可，不需要重复创建和执行

console.log(a, fn);//=>12 函数本身






