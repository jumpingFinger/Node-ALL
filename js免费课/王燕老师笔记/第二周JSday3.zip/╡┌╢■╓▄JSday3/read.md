## 数组常用的方法
- push()将内容添加到数组末尾的位置
- pop() 删除最后一项
- unshift() 添加到数组的开始位置
- shift() 删除第一项
- reverse() 反向排列
- sort(function(a,b){return a-b})  可以从小到大或从大到小排列
- splice(n,m,x) 从索引n开始删除m个,用x的内容替换删除的内容
- concat() 合并数组
- slice(n,m)从索引n截取到索引m(包前不包后)
- join("&")按照指定字符将数组拼接成字符串 
- join()"5,6,3" 拼接字符就是逗号
- join("")数组的每一项靠一起返回一个字符串
- toString() 转换成字符串
- indexOf() lastIndexOf() 判断数组是否有这一项，若有则返回这一项的索引，没有则返回-1

## DOM节点的类型 
                  nodeType             nodeName      nodeValue
 - 文档节点          9                   #document       null
 - 元素节点          1                   大写的标记名      null   
 - 文本节点          3                   #text           文本的内容（包括换行）
 - 注释节点          8                   #comment        注释的内容        
 
## DOM节点之间相互关系的属性
- childNodes 所有的子节点 
- children  所有的子元素节点（IE8及以下浏览器不支持）
- previousSibling 哥哥节点
- previousElementSibling 哥哥元素节点（IE8及以下浏览器不支持）
- nextSibling 弟弟节点
- nextElementSibling 弟弟元素节点（IE8及以下浏览器不支持）
- firstChild  第一个子节点
- firstElementChild 第一个子元素节点（IE8及以下浏览器不支持）
- lastChild  最后一个子节点
- lastElementChild 最后一个子元素节点（IE8及以下浏览器不支持）
- parentNode 父节点 

## 动态的操作DOM元素
- 创建节点
 > document.createElement("div") 元素节点
 > document.createTextNode("天气不错~~~") 文本节点

- 添加节点 
父节点.appendChild(oDiv) 添加到父节点内容末尾的位置

- 替换节点
父节点.replaceChild(newEle,oldEle);

- 删除节点
父节点.removeChild(ele);

- 克隆节点
被克隆的元素.cloneNode() 不写参数默认为false 表示浅克隆 可参数true 深度克隆

## 操作字符串常用的方法（11个）
- charAt(n) 通过索引n获取对应的字符
- charCodeAt(n)通过索引n获取对应字符的ASCII码值  
> 转换大小写
- toLowerCase() 转换成小写
- toUpperCase() 转换成大写
>截取字符串
- substr(n,m) 从索引n开始截取m个
- substring(n,m) 从索引n开始截取到索引m（包前不包后）
 奇怪的规则：
 n>m 时 n和m自动交换位置
 负数索引会转换为0
- slice(n,m) 从索引n开始截取到索引m （包前不包后） ->推荐用slice() 
 可以是负数索引
 n>m时返回""

- split("&") 按照指定的字符将字符串拆分数组的每一项
- replace("珠峰","zf") 替换字符串

判断字符串中是否有这个字符
若找到则返回对应索引，找不到则返回-1
- indexOf()
- lastIndexOf()

## 定时器
setTimeout([Function],[interval]) 间隔一段时间执行一次
setInterval([Function],[interval]) 每隔一个间隔时间就会执行一次

清除定时器
clearTimeout(timer) 清除timer的定时器
clearInterval(timer)
 
 
 如何判断定时器是启动的还是停止的？
 1.清除定时器时，timer人为设成null
 2.若timer值为null，说明定时器时停止(清除定时器)的，若timer不是null,是个数值，则说明定时器时启动(开启定时器)的

