### Math

### DOM
当浏览器渲染页面时，页面上所有的内容会渲染成相应的有层次结构的DOM节点，一个页面有一个根节点（document）,根节点下只有一个根元素（html）
DOM节点分类：

              节点类型（nodeType）     节点名称(nodeName)      节点值(nodeValue)
文档节点             9                      #document                null    
元素节点             1                      大写的标记名               null
文本节点             3                      #text                文本的内容（空格和换行）     
注释节点             8                      #comment             注释的内容     

JS中表示DOM节点之间相互关系的属性
1.childNodes  所有的子节点
2.children    子元素节点  IE8浏览器会把文本节点也当成元素节点
3.previousSibling 哥哥节点
4.previousElementSibling 哥哥元素节点（ie8及以下浏览器不支持）
5.nextSibling  弟弟节点
6.nextElementSibling  弟弟元素节点（ie8及以下浏览器不支持）
7.firstChild 第一个子节点
8.firstElementChild 第一个子元素节点 （ie8及以下浏览器不支持）
9.lastChild 最后一个子节点
10.lastElementChild 最后一个子元素节点 （ie8及以下浏览器不支持）
11.parentNode 父节点


### 获取元素的方法
- id名 document.getElementById("div1")  调用的主体只能是document
- 标记名（tagName）context.getElementsByTagName("li")
- 类名 className  context.getElementsByClassName("a1") 
  - 有兼容性问题
- name属性   document.getElementsByName("text"); 调用的主体只能是document
    - IE浏览器下，这种方式只对表单元素起作用
*移动端常用的获取元素的方式*    
- document.querySelector(选择器) 获取一个元素
- document.querySelectorAll(选择器)  获取的是元素集合
- 获取浏览器可视窗口的宽高
document.documentElement.clientWidth||document.body.clientWidth  窗口的宽
document.documentElement.clientHeight||document.body.clientHeight 窗口的高

document.documentElement  html元素
document.body   body元素
需求：让一个盒子在可视窗口中水平垂直居中？


