class Game {
  constructor(){

  }
  init(){

  }
}